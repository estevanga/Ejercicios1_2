1. Ingresar a Cypress
2. Ejecutar el spec CrearUsuarios
3. Ejecutar el spec BuscarUsuario  // Usuario Creado
4. Ejecutar el spec ActualizarUsuario
5. Ejecutar el spec BuscarUsuario   // Usuario Actualizado
6. Ejecutar el spec Eliminar Usuario

