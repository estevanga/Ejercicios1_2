//Automatizacion de carrito de compras`
import { Factura} from '../support/Api/Factura'

require('@cypress/xpath');
Cypress.on("uncaught:exception", (err, runnable) => {
  return false;
});

//Describe el escenario para la automatizacion

describe('Ejercicio 1', () => {
  let   registerData 
  before ("before", ()=>{
    cy.fixture('datosFactura').then(data=>{
      registerData = data;
    });
  
  });
    
   //crear instancia de nuestra clase 
   const factura = new Factura ();

    it('Comparar', () => {
      cy.visit('https://opencart.abstracta.us/')
      //Add first itenm to cart     
      cy.screenshot('Inicio') 
      cy.get('a[href*="path=57"]').eq(2).click()
      cy.get('button[id="button-cart"]').click()
      // Add another item to cart
      cy.wait(1000)
      cy.screenshot('Primer Item') 
      cy.visit('https://opencart.abstracta.us/index.php?route=product/product&path=33&product_id=30')
      //Select red color
      cy.get("select").select(1).invoke("val").should("eq", "15")
      //
      cy.get('button[id="button-cart"]').click()
      
      cy.get('.btn-inverse').eq(0).should('be.visible').click({force: true})
      cy.screenshot('SegundoItem') 
      cy.wait(2000)  
      //Checkout
      cy.visit('https://opencart.abstracta.us/index.php?route=checkout/cart')
      cy.get('.btn-primary').eq(5).should('be.visible').click({force: true})
      //Guest checkout
      cy.get('[type="radio"]').check('guest')
      //Continue
      cy.get('.btn-primary').eq(0).click()
      //Fill input values
      factura.writeFirstName (registerData.firstname);
      factura.writeLastName (registerData.lastname);
      factura.writeEmail (registerData.email);
      factura.writeTelephone (registerData.telephone);
      factura.writeCompany (registerData.company);
      factura.writeAddress_1(registerData.address_1);
      factura.writeAddress_2(registerData.address_2);
      factura.writeCity(registerData.city);
      factura.writePostCode(registerData.postcode);
      //Set Ecuador 62
      cy.get("select#input-payment-country").select(68).invoke("val").should("eq", "62")
      //Set Pichincha 997
      cy.get('select#input-payment-zone').select('997').should('have.value', '997')
      cy.screenshot('Formulario') 
     
      cy.get('.btn-primary').eq(2).click({force:true})
      cy.wait(2000)
      cy.get('.btn-primary').eq(4).click({force:true})
      cy.wait(1000)
        //Guest checkout
      cy.get('[type="radio"]').check('cod')
      //Accept Legcy
      cy.get('[type="checkbox"]').eq(1).check()
      //End Button
      cy.screenshot('GuessCheckout') 

      cy.get('.btn-primary').eq(5).click({force:true})
      cy.wait(1000)
      //Confirm button
      cy.xpath("//input[@id='button-confirm']").click({force:true})
    })
  })